<?php
/**
 * ============================================================================
 *  eoc_data_add.php
 *  หน้าบันทึก/แก้ไขข้อมูลการช่วยเหลือผู้ป่วยกลุ่มเปราะบาง (Full-page)
 *  ระบบ VOC – Vulnerable Operations Center (Thepha Care)
 * ----------------------------------------------------------------------------
 *  ✅ อัปเดต:
 *     - สถานะการดำเนินการแปรผลอัตโนมัติจากผลการบริการ
 *       · success                    → completed (เสร็จสิ้น, พื้นหลังเขียว)
 *       · pending | partial | failed → in_progress (กำลังดำเนินการ, พื้นหลังแดง)
 *     - ปุ่ม Action (ยกเลิก / บันทึก) แสดงเฉพาะไอคอน + tooltip
 * ============================================================================
 */

// ============================================
// 0) Bootstrap กลาง
// ============================================
require_once __DIR__ . '/includes/bootstrap.php';
$timeout_duration = $timeout_duration ?? 900;

require_once __DIR__ . '/includes/group_context.php';
$__group     = eoc_resolve_group($pdo);
$group_code  = $__group['gstatus_id'];
$group_name  = $__group['gstatus_name'];
$group_icon  = $__group['icon'];
$group_color = $__group['color'];

if (function_exists('eoc_all_groups')) {
    $__groups_all = eoc_all_groups($pdo);
    if (!isset($__groups_all[$group_code])) {
        header('Location: eoc_data.php?g=g1');
        exit;
    }
}

$user_name       = $user_name ?? 'ไม่ระบุชื่อ';
$user_hospcode   = (string)($user_hospcode ?? ($_SESSION['user_hospcode'] ?? ''));
$status_user     = $status_user ?? 'ไม่ระบุสถานะ';
$current_user_id = (int)($_SESSION['user_id'] ?? 0);

if (!preg_match('/^#[0-9A-Fa-f]{6}$/', (string)$group_color)) {
    $group_color = '#6366F1';
}

const EOC_MAX_MESSAGE = 2000;
const EOC_FLASH_KEY   = 'eoc_add_flash';

// ============================================
// 1) Helpers
// ============================================
function eoc_hex_rgba($hex, $alpha = 1) {
    $hex = ltrim((string)$hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    if (strlen($hex) !== 6 || !ctype_xdigit($hex)) $hex = '6B7280';
    $a = rtrim(rtrim(number_format((float)$alpha, 2, '.', ''), '0'), '.');
    return sprintf('rgba(%d, %d, %d, %s)',
        hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)),
        ($a === '') ? '0' : $a);
}

if (!function_exists('eoc_fa_icon')) {
    function eoc_fa_icon($icon, $fallback = 'fas fa-file-medical') {
        $icon = trim((string)$icon);
        if ($icon === '' || strpos($icon, 'fa-') === false) return $fallback;
        if (!preg_match('/^(fas|far|fab|fal|fad|fa-solid|fa-regular|fa-brands)\s/', $icon)) return 'fas ' . $icon;
        return $icon;
    }
}

function eoc_h($value) {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function eoc_generate_service_no(PDO $pdo) {
    $stmt = $pdo->query("
        SELECT MAX(CAST(SUBSTRING(service_no, 5) AS UNSIGNED)) AS max_no
        FROM eoc_services
        WHERE service_no LIKE 'pro\\_%'
          AND SUBSTRING(service_no, 5) REGEXP '^[0-9]{1,10}$'
    ");
    $row  = $stmt ? $stmt->fetch(PDO::FETCH_ASSOC) : null;
    $next = ((int)($row['max_no'] ?? 0)) + 1;
    return 'pro_' . str_pad((string)$next, 10, '0', STR_PAD_LEFT);
}

/**
 * ✅ แปลงผลการบริการ → สถานะการดำเนินการ (อัตโนมัติ)
 *    - success                     → completed    (เสร็จสิ้น)
 *    - pending / partial / failed  → in_progress  (กำลังดำเนินการ)
 */
function eoc_map_status_from_result(string $result): string
{
    return ($result === 'success') ? 'completed' : 'in_progress';
}

$group_icon = eoc_fa_icon($__group['icon'] ?? '', 'fas fa-user-injured');

// ============================================
// 2) ตรวจ idcard
// ============================================
$idcard           = trim((string)($_GET['idcard'] ?? ''));
$pick_patient_url = 'eoc_data.php?g=' . urlencode($group_code);

if ($idcard === '') {
    header('Location: ' . $pick_patient_url, true, 302);
    exit;
}
if (!preg_match('/^\d{13}$/', $idcard)) {
    $_SESSION['error_message'] = 'รหัสบัตรประชาชนไม่ถูกต้อง กรุณาเลือกผู้ป่วยใหม่อีกครั้ง';
    header('Location: ' . $pick_patient_url, true, 302);
    exit;
}

// ============================================
// 3) ดึงข้อมูลผู้ป่วย
// ============================================
$patient = null;
try {
    $stmt_patient = $pdo->prepare("
        SELECT e.id, e.idcard, e.gstatus, e.emergency_code,
               p.name, p.age, p.gender, p.hospcode,
               h.hosp_name AS hospital,
               el.emergency_name,
               p.mobile AS patient_phone
        FROM eoc_pop e
        LEFT JOIN person p ON e.idcard = p.idcard
        LEFT JOIN hospital h ON p.hospcode = h.hospcode
        LEFT JOIN eoc_emergency_level el ON e.emergency_code = el.emergency_code
        WHERE e.idcard = ? AND e.gstatus = ?
        LIMIT 1
    ");
    $stmt_patient->execute([$idcard, $group_code]);
    $patient = $stmt_patient->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log('[eoc_data_add] fetch patient: ' . $e->getMessage());
}

if (!$patient) {
    $_SESSION['error_message'] = 'ไม่พบข้อมูลผู้ป่วยที่เลือก กรุณาตรวจสอบแล้วเลือกใหม่อีกครั้ง';
    header('Location: ' . $pick_patient_url, true, 302);
    exit;
}

$service_url = 'eoc_data_service.php?g=' . urlencode($group_code) . '&idcard=' . urlencode($idcard);

// ============================================
// 4) Master data
// ============================================
$request_types    = [];
$referral_centers = [];

try {
    $request_types = $pdo->query("
        SELECT request_code, request_name, request_icon, request_color
        FROM eoc_mas_request_type
        WHERE is_active = 1
        ORDER BY display_order ASC, request_code ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { error_log('[eoc_data_add] request types: ' . $e->getMessage()); }

try {
    $referral_centers = $pdo->query("
        SELECT center_code, center_name, center_type, phone
        FROM eoc_mas_referral_center
        WHERE is_active = 1
        ORDER BY display_order ASC, center_code ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { error_log('[eoc_data_add] referral centers: ' . $e->getMessage()); }

$request_type_index = [];
foreach ($request_types as $rt) {
    $color = (string)($rt['request_color'] ?? '');
    $request_type_index[(string)$rt['request_code']] = [
        'name'  => (string)($rt['request_name'] ?? $rt['request_code']),
        'icon'  => eoc_fa_icon($rt['request_icon'] ?? '', 'fas fa-file-medical'),
        'color' => preg_match('/^#[0-9A-Fa-f]{6}$/', $color) ? $color : '#3B82F6',
    ];
}

$valid_results       = ['pending', 'success', 'partial', 'failed'];
$need_location_types = ['shelter', 'transport'];

// ============================================
// 5) โหมด edit
// ============================================
$edit_service_no = trim((string)($_GET['edit'] ?? $_POST['edit'] ?? ''));
$is_edit_mode    = ($edit_service_no !== '');
$edit_data       = null;

if ($is_edit_mode) {
    try {
        $stmt_edit = $pdo->prepare("
            SELECT service_no, request_type, message, service_date,
                   service_detail, service_provider, service_location,
                   service_result, status
            FROM eoc_services
            WHERE service_no = ? AND idcard = ?
            LIMIT 1
        ");
        $stmt_edit->execute([$edit_service_no, $idcard]);
        $edit_data = $stmt_edit->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log('[eoc_data_add] fetch edit: ' . $e->getMessage());
    }

    if (!$edit_data) {
        $_SESSION['error_message'] = 'ไม่พบรายการที่ต้องการแก้ไข กรุณาตรวจสอบเลขที่บริการอีกครั้ง';
        header('Location: ' . $service_url, true, 302);
        exit;
    }
}

// ============================================
// 6) ค่าเริ่มต้นฟอร์ม
// ============================================
$form = [
    'request_type'           => '',
    'message'                => '',
    'service_detail'         => '',
    'service_provider'       => $user_name,
    'service_location'       => '',
    'service_location_other' => '',
    'service_result'         => 'pending',
    'status'                 => 'in_progress',
    'service_date'           => date('Y-m-d'),
];

// ✅ แปรผลสถานะอัตโนมัติจากผลการบริการเริ่มต้น
$form['status'] = eoc_map_status_from_result($form['service_result']);

if ($is_edit_mode && $edit_data) {
    $saved_location  = (string)($edit_data['service_location'] ?? '');
    $known_locations = array_column($referral_centers, 'center_name');

    $form['request_type']     = (string)($edit_data['request_type'] ?? '');
    $form['message']          = (string)($edit_data['message'] ?? '');
    $form['service_detail']   = (string)($edit_data['service_detail'] ?? '');
    $form['service_provider'] = (string)($edit_data['service_provider'] ?? '');
    $form['service_result']   = (string)($edit_data['service_result'] ?? 'pending');
    $form['service_date']     = !empty($edit_data['service_date'])
        ? date('Y-m-d', strtotime((string)$edit_data['service_date']))
        : date('Y-m-d');

    // ✅ สถานะใน edit mode → แปรผลจาก service_result เสมอ
    $form['status'] = eoc_map_status_from_result($form['service_result']);

    if ($saved_location !== '') {
        if (in_array($saved_location, $known_locations, true)) {
            $form['service_location'] = $saved_location;
        } else {
            $form['service_location']       = 'other';
            $form['service_location_other'] = $saved_location;
        }
    }
}

$errors = [];

if (!empty($_SESSION[EOC_FLASH_KEY]) && is_array($_SESSION[EOC_FLASH_KEY])) {
    $flash = $_SESSION[EOC_FLASH_KEY];
    unset($_SESSION[EOC_FLASH_KEY]);
    $errors = is_array($flash['errors'] ?? null) ? $flash['errors'] : [];
    if (is_array($flash['form'] ?? null)) {
        $form = array_merge($form, $flash['form']);
    }
    // ✅ บังคับแปรผลสถานะใหม่เสมอ
    $form['status'] = eoc_map_status_from_result($form['service_result']);
}

// CSRF
if (empty($_SESSION['eoc_add_token'])) {
    $_SESSION['eoc_add_token'] = bin2hex(random_bytes(32));
}
$form_token = $_SESSION['eoc_add_token'];

// ============================================
// 7) POST: บันทึก / แก้ไข
// ============================================
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {

    $posted_token = (string)($_POST['form_token'] ?? '');
    if (!hash_equals($form_token, $posted_token)) {
        $_SESSION['error_message'] = 'แบบฟอร์มหมดอายุหรือไม่ถูกต้อง กรุณาเปิดหน้าใหม่แล้วลองอีกครั้ง';
        header('Location: ' . $service_url, true, 302);
        exit;
    }

    $form['request_type']           = trim((string)($_POST['request_type'] ?? ''));
    $form['message']                = trim((string)($_POST['message'] ?? ''));
    $form['service_detail']         = trim((string)($_POST['service_detail'] ?? ''));
    $form['service_provider']       = trim((string)($_POST['service_provider'] ?? ''));
    $form['service_location']       = trim((string)($_POST['service_location'] ?? ''));
    $form['service_location_other'] = trim((string)($_POST['service_location_other'] ?? ''));
    $form['service_result']         = strtolower(trim((string)($_POST['service_result'] ?? '')));

    $date_raw = (string)($_POST['service_date'] ?? '');
    $date_ts  = strtotime($date_raw !== '' ? $date_raw : date('Y-m-d'));
    $form['service_date'] = $date_ts ? date('Y-m-d', $date_ts) : date('Y-m-d');

    if ($form['request_type'] === '') {
        $errors['request_type'] = 'กรุณาเลือกประเภทการร้องขอ';
    } elseif (!isset($request_type_index[$form['request_type']])) {
        $errors['request_type'] = 'ประเภทการร้องขอไม่ถูกต้อง กรุณาเลือกใหม่';
        $form['request_type'] = '';
    }

    if ($form['message'] === '') {
        $errors['message'] = 'กรุณาระบุรายละเอียดที่ต้องการรับความช่วยเหลือ';
    } elseif (mb_strlen($form['message'], 'UTF-8') > EOC_MAX_MESSAGE) {
        $errors['message'] = 'รายละเอียดยาวเกินกำหนด (' . EOC_MAX_MESSAGE . ' ตัวอักษร)';
    }

    if (mb_strlen($form['service_detail'], 'UTF-8') > EOC_MAX_MESSAGE) {
        $errors['service_detail'] = 'รายละเอียดการบริการยาวเกินกำหนด';
    }
    if (mb_strlen($form['service_provider'], 'UTF-8') > 255) {
        $errors['service_provider'] = 'ชื่อผู้ให้บริการยาวเกินกำหนด (255 ตัวอักษร)';
    }

    if (in_array($form['request_type'], $need_location_types, true)) {
        if ($form['service_location'] === '') {
            $errors['service_location'] = 'กรุณาเลือกสถานที่/ศูนย์ที่ดำเนินการ';
        } elseif ($form['service_location'] === 'other' && $form['service_location_other'] === '') {
            $errors['service_location_other'] = 'กรุณาระบุสถานที่อื่นๆ ที่ต้องการ';
        }
    }

    if (!in_array($form['service_result'], $valid_results, true)) {
        $form['service_result'] = 'pending';
    }

    // ✅ บังคับแปรผลสถานะจากผลการบริการ
    $form['status'] = eoc_map_status_from_result($form['service_result']);

    if (!empty($errors)) {
        $_SESSION[EOC_FLASH_KEY] = ['errors' => $errors, 'form' => $form];
        $redirect_url = 'eoc_data_add.php?g=' . urlencode($group_code) . '&idcard=' . urlencode($idcard)
                      . ($is_edit_mode ? '&edit=' . urlencode($edit_service_no) : '');
        header('Location: ' . $redirect_url, true, 302);
        exit;
    }

    if ($form['service_location'] === 'other') {
        $service_location = $form['service_location_other'];
    } elseif (in_array($form['request_type'], $need_location_types, true)) {
        $service_location = $form['service_location'];
    } else {
        $service_location = '';
    }

    $self_url = 'eoc_data_add.php?g=' . urlencode($group_code) . '&idcard=' . urlencode($idcard)
              . ($is_edit_mode ? '&edit=' . urlencode($edit_service_no) : '');

    try {
        $pdo->beginTransaction();

        if ($is_edit_mode) {
            $update_stmt = $pdo->prepare("
                UPDATE eoc_services SET
                    request_type     = :request_type,
                    message          = :message,
                    service_date     = :service_date,
                    service_detail   = :service_detail,
                    service_provider = :service_provider,
                    service_location = :service_location,
                    service_result   = :service_result,
                    status           = :status,
                    d_update         = NOW()
                WHERE service_no = :service_no AND idcard = :idcard
            ");
            $update_stmt->execute([
                'request_type'     => $form['request_type'],
                'message'          => $form['message'],
                'service_date'     => $form['service_date'],
                'service_detail'   => $form['service_detail'],
                'service_provider' => $form['service_provider'] !== '' ? $form['service_provider'] : $user_name,
                'service_location' => mb_substr((string)$service_location, 0, 255, 'UTF-8'),
                'service_result'   => $form['service_result'],
                'status'           => $form['status'],
                'service_no'       => $edit_service_no,
                'idcard'           => $idcard,
            ]);

            if ($update_stmt->rowCount() === 0) {
                $stmt_chk = $pdo->prepare('SELECT 1 FROM eoc_services WHERE service_no = ? AND idcard = ?');
                $stmt_chk->execute([$edit_service_no, $idcard]);
                if ($stmt_chk->fetchColumn() === false) {
                    throw new PDOException('ไม่พบรายการที่ต้องการแก้ไข');
                }
            }

            $pdo->commit();
            $_SESSION['success_message'] = "อัปเดตข้อมูลการช่วยเหลือเรียบร้อยแล้ว (เลขที่บริการ: {$edit_service_no})";
        } else {
            $new_service_no = eoc_generate_service_no($pdo);

            $insert_stmt = $pdo->prepare("
                INSERT INTO eoc_services (
                    service_no, idcard, request_type, message, service_date,
                    service_detail, service_provider, service_location, service_result,
                    status, add_by, created_by, created_at, d_update
                ) VALUES (
                    :service_no, :idcard, :request_type, :message, :service_date,
                    :service_detail, :service_provider, :service_location, :service_result,
                    :status, 'provider', :created_by, NOW(), NOW()
                )
            ");
            $insert_stmt->execute([
                'service_no'       => $new_service_no,
                'idcard'           => $idcard,
                'request_type'     => $form['request_type'],
                'message'          => $form['message'],
                'service_date'     => $form['service_date'],
                'service_detail'   => $form['service_detail'],
                'service_provider' => $form['service_provider'] !== '' ? $form['service_provider'] : $user_name,
                'service_location' => mb_substr((string)$service_location, 0, 255, 'UTF-8'),
                'service_result'   => $form['service_result'],
                'status'           => $form['status'],
                'created_by'       => $current_user_id,
            ]);

            $pdo->commit();
            $_SESSION['success_message'] = "บันทึกข้อมูลการช่วยเหลือเรียบร้อยแล้ว (เลขที่บริการ: {$new_service_no})";
        }

        $_SESSION['eoc_add_token'] = bin2hex(random_bytes(32));
        header('Location: ' . $service_url, true, 302);
        exit;

    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[eoc_data_add] save: ' . $e->getMessage());
        $_SESSION[EOC_FLASH_KEY] = [
            'errors' => ['_form' => 'เกิดข้อผิดพลาดในการบันทึกข้อมูล กรุณาลองอีกครั้งหรือแจ้งผู้ดูแลระบบ'],
            'form'   => $form,
        ];
        header('Location: ' . $self_url, true, 302);
        exit;
    }
}

// ============================================
// 8) ข้อมูลสำหรับแสดงผล
// ============================================
$result_labels = [
    'pending' => ['text' => 'รอดำเนินการ',     'icon' => 'fas fa-hourglass-half',     'color' => '#D97706'],
    'success' => ['text' => 'สำเร็จ',            'icon' => 'fas fa-circle-check',       'color' => '#059669'],
    'partial' => ['text' => 'สำเร็จบางส่วน',    'icon' => 'fas fa-circle-half-stroke', 'color' => '#2563EB'],
    'failed'  => ['text' => 'ไม่สำเร็จ',         'icon' => 'fas fa-circle-xmark',       'color' => '#DC2626'],
];

$existing_count = 0;
try {
    $stmt_count = $pdo->prepare('SELECT COUNT(*) FROM eoc_services WHERE idcard = ?');
    $stmt_count->execute([$idcard]);
    $existing_count = (int)$stmt_count->fetchColumn();
} catch (PDOException $e) { error_log('[eoc_data_add] count: ' . $e->getMessage()); }

$time_left = max(0, $timeout_duration - (time() - (int)($_SESSION['last_activity'] ?? time())));
$time_left_formatted = sprintf('%02d:%02d', floor($time_left / 60), $time_left % 60);

$need_location_json = json_encode(array_values($need_location_types));

$__success_msg = $_SESSION['success_message'] ?? null;
$__error_msg   = $_SESSION['error_message']   ?? null;
unset($_SESSION['success_message'], $_SESSION['error_message']);

$__status_is_success = ($form['status'] === 'completed');
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="theme-color" content="#1E293B">
<title><?= $is_edit_mode ? 'แก้ไขข้อมูลการช่วยเหลือ' : 'บันทึกข้อมูลการช่วยเหลือ' ?> | <?= eoc_h($patient['name'] ?? $idcard) ?> | VOC Thepha Care</title>

<link rel="dns-prefetch" href="//cdn.tailwindcss.com">
<link rel="dns-prefetch" href="//cdnjs.cloudflare.com">
<link rel="preconnect" href="https://cdn.tailwindcss.com">
<link rel="preconnect" href="https://cdnjs.cloudflare.com">

<script src="https://cdn.tailwindcss.com"></script>
<script defer src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"></noscript>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Kanit:wght@400;600&display=swap" rel="stylesheet">

<style>
:root {
    --gc: <?= eoc_h($group_color) ?>;
    --gc-soft: <?= eoc_hex_rgba($group_color, 0.12) ?>;
    --gc-glow: <?= eoc_hex_rgba($group_color, 0.32) ?>;
}
*, *::before, *::after { box-sizing: border-box; }
html { font-size: 16px; -webkit-text-size-adjust: 100%; }
body {
    font-family: 'Kanit', system-ui, -apple-system, sans-serif;
    font-weight: 400;
    font-size: 15px;
    background: #F8FAFC;
    min-height: 100vh;
    min-height: 100dvh;
    line-height: 1.5;
    overflow-x: hidden;
    -webkit-tap-highlight-color: transparent;
}
body.nav-open { overflow: hidden; }

.gradient-bg { background: #1E293B; }
.glass-effect { background: rgba(255,255,255,0.12); border: 1px solid rgba(255,255,255,0.15); }

.header-safe { padding-left: max(1rem, env(safe-area-inset-left, 0px)); padding-right: max(1rem, env(safe-area-inset-right, 0px)); }
.main-safe   { padding-left: max(1rem, env(safe-area-inset-left, 0px)); padding-right: max(1rem, env(safe-area-inset-right, 0px)); }
@media (min-width: 640px) { .header-safe, .main-safe { padding-left: max(1.5rem, env(safe-area-inset-left, 0px)); padding-right: max(1.5rem, env(safe-area-inset-right, 0px)); } }
@media (min-width: 1024px){ .header-safe, .main-safe { padding-left: max(2rem, env(safe-area-inset-left, 0px)); padding-right: max(2rem, env(safe-area-inset-right, 0px)); } }

.main-content { min-width: 0; overflow-x: clip; }
.eoc-side-top, .eoc-backdrop { display: none; }
@media (min-width: 1024px) {
    .main-content { margin-left: 288px; }
    .eoc-side { display: contents; }
}
@media (max-width: 1023.98px) {
    .eoc-side {
        position: fixed; top: 0; bottom: 0; left: 0;
        width: min(86vw, 20rem); z-index: 60; background: #fff;
        overflow-y: auto; overscroll-behavior: contain;
        padding: 0 .75rem calc(1rem + env(safe-area-inset-bottom, 0px));
        transform: translateX(-100%); visibility: hidden;
    }
    .eoc-side.open { transform: none; visibility: visible; box-shadow: 0 0 40px rgba(0,0,0,.35); }
    .eoc-side-top {
        display: flex; align-items: center; justify-content: space-between;
        position: sticky; top: 0; z-index: 1;
        background: #fff;
        padding: calc(.75rem + env(safe-area-inset-top, 0px)) 0 .75rem;
        margin-bottom: .5rem;
        border-bottom: 1px solid #E5E7EB;
        font-weight: 600; color: #1E293B;
    }
    .eoc-side-top button { width: 44px; height: 44px; border: 1px solid #E5E7EB; border-radius: 10px; background: #F8FAFC; cursor: pointer; }
    .eoc-side > *:not(.eoc-side-top) {
        position: static !important; inset: auto !important; transform: none !important;
        width: 100% !important; max-width: 100% !important; height: auto !important;
    }
    .eoc-side > .hidden { display: block !important; }
    .eoc-backdrop { display: block; position: fixed; inset: 0; z-index: 55; background: rgba(15,23,42,.5); }
    .eoc-backdrop[hidden] { display: none; }
    .main-content { margin-left: 0; }
}

.info-card {
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
    border: 1px solid rgba(0,0,0,0.04);
    overflow: hidden;
}

/* ============================================
   ปุ่ม action — ไอคอนเท่านั้น (มี tooltip ผ่าน title)
   ============================================ */
.btn-action {
    display: inline-flex; align-items: center; justify-content: center;
    width: 42px; height: 42px;
    border-radius: 0.6rem;
    font-size: 1rem; color: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.12);
    cursor: pointer;
    text-decoration: none; border: none;
    flex-shrink: 0;
    position: relative;
}
.btn-action:active { opacity: 0.85; }
.btn-action:disabled { opacity: 0.55; cursor: not-allowed; }
.btn-action i { font-size: 0.95rem; }

/* ปุ่มขนาดใหญ่ขึ้นเล็กน้อยเมื่อเป็นปุ่มหลักของ form-actions */
.btn-action.btn-lg {
    width: 46px; height: 46px;
    font-size: 1.05rem;
}
.btn-action.btn-lg i { font-size: 1.05rem; }

.btn-back    { background: #6b7280; }
.btn-edit    { background: var(--gc); }
.btn-setup   { background: #3B82F6; }
.btn-service { background: #10b981; }
.btn-delete  { background: #EF4444; }
.btn-share   { background: #3B82F6; }
.btn-yellow  { background: #F59E0B; }
.btn-purple  { background: #8B5CF6; }
.btn-info    { background: #3B82F6; }

/* Tooltip (pure CSS) */
.btn-action[title]:hover::after,
.btn-action[title]:focus-visible::after {
    content: attr(title);
    position: absolute;
    bottom: calc(100% + 6px);
    left: 50%;
    transform: translateX(-50%);
    background: #0F172A;
    color: #fff;
    font-size: 0.72rem;
    font-weight: 500;
    padding: 0.35rem 0.6rem;
    border-radius: 0.4rem;
    white-space: nowrap;
    pointer-events: none;
    z-index: 50;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}
.btn-action[title]:hover::before,
.btn-action[title]:focus-visible::before {
    content: '';
    position: absolute;
    bottom: calc(100% + 1px);
    left: 50%;
    transform: translateX(-50%);
    border: 5px solid transparent;
    border-top-color: #0F172A;
    pointer-events: none;
    z-index: 50;
}
/* ไม่ต้องมี tooltip บนปุ่ม disabled */
.btn-action[disabled][title]:hover::after,
.btn-action[disabled][title]:hover::before { display: none; }

.patient-bar {
    display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
    background: #F8FAFC; border: 1px solid #E2E8F0;
    border-left: 5px solid var(--gc);
    border-radius: 1rem; padding: 1rem 1.15rem;
}
.patient-bar .av {
    width: 3rem; height: 3rem; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    border-radius: 9999px; color: #fff; font-size: 1.15rem;
    background: var(--gc);
}
.patient-bar .meta { display: flex; flex-wrap: wrap; gap: 0.35rem 1rem; margin-top: 0.25rem; }
.patient-bar .meta span { display: inline-flex; align-items: center; gap: 0.35rem; font-size: 0.78rem; color: #475569; }
.patient-bar .meta i { color: var(--gc); }

.fsec {
    background: #fff; border: 1px solid #E2E8F0;
    border-radius: 1rem; padding: 1.15rem 1.25rem 1.3rem;
    box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
    scroll-margin-top: 90px;
}
.fsec + .fsec { margin-top: 1rem; }
.fsec-head { display: flex; align-items: flex-start; gap: 0.8rem; margin-bottom: 1.05rem; }
.fnum {
    width: 2.15rem; height: 2.15rem; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    border-radius: 0.75rem; color: #fff; font-weight: 700; font-size: 0.88rem;
    background: var(--gc);
}
.fsec-head h4 { font-size: 0.98rem; font-weight: 700; color: #0F172A; }
.fsec-head p { font-size: 0.76rem; color: #64748B; margin-top: 0.12rem; }

.fld-label {
    display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;
    font-size: 0.84rem; font-weight: 600; color: #334155; margin-bottom: 0.45rem;
}
.fld-label .l { display: inline-flex; align-items: center; gap: 0.4rem; }
.fld-label .l i { color: var(--gc); }
.req {
    display: inline-flex; align-items: center;
    font-size: 0.66rem; font-weight: 700; color: #DC2626;
    background: #FEF2F2; border: 1px solid #FECACA;
    border-radius: 9999px; padding: 0.1rem 0.55rem;
}
.opt {
    display: inline-flex; align-items: center;
    font-size: 0.66rem; font-weight: 600; color: #64748B;
    background: #F1F5F9; border: 1px solid #E2E8F0;
    border-radius: 9999px; padding: 0.1rem 0.55rem;
}
.fld {
    width: 100%; font-size: 0.9rem; color: #0F172A;
    background: #fff; border: 1.5px solid #CBD5E1; border-radius: 0.75rem;
    padding: 0.7rem 0.9rem; outline: none;
    transition: none !important;
}
.fld:focus { border-color: var(--gc); box-shadow: 0 0 0 4px var(--gc-soft); }
.fld[readonly] { background: #F8FAFC; color: #475569; cursor: not-allowed; }
select.fld { appearance: none; -webkit-appearance: none; padding-right: 2.4rem; cursor: pointer; }
textarea.fld { line-height: 1.6; resize: vertical; min-height: 92px; }
.fld-wrap { position: relative; }
.fld-wrap .chev { position: absolute; right: 0.9rem; top: 50%; transform: translateY(-50%); color: #94A3B8; font-size: 0.75rem; pointer-events: none; }

.fld.is-error { border-color: #EF4444; background: #FEF2F2; }
.err-msg { display: flex; align-items: center; gap: 0.35rem; font-size: 0.74rem; color: #DC2626; margin-top: 0.4rem; font-weight: 500; }
.fld-hint { font-size: 0.74rem; color: #64748B; margin-top: 0.4rem; display: flex; gap: 0.35rem; align-items: flex-start; }
.fld-hint i { margin-top: 0.18rem; color: #94A3B8; }
.char-row { display: flex; justify-content: space-between; align-items: center; margin-top: 0.3rem; }
.char-count { font-size: 0.7rem; color: #94A3B8; font-variant-numeric: tabular-nums; }
.char-count.warn { color: #D97706; font-weight: 600; }
.char-count.over { color: #DC2626; font-weight: 700; }

.pick-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 0.7rem; }
.pick { position: relative; display: block; cursor: pointer; }
.pick input { position: absolute; opacity: 0; pointer-events: none; }
.pick-card {
    display: flex; align-items: center; gap: 0.7rem; height: 100%;
    border: 1.5px solid #E2E8F0; background: #F8FAFC;
    border-radius: 0.9rem; padding: 0.7rem 0.8rem;
}
.pick-card .dot {
    width: 2.35rem; height: 2.35rem; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    border-radius: 0.75rem; background: #fff; border: 1px solid #E2E8F0;
    font-size: 0.95rem;
}
.pick-card .txt { min-width: 0; }
.pick-card b { display: block; font-size: 0.84rem; color: #0F172A; font-weight: 600; }
.pick-card .tick { margin-left: auto; color: var(--gc); opacity: 0; flex-shrink: 0; }
.pick:hover .pick-card { border-color: #94A3B8; background: #fff; }
.pick input:checked + .pick-card { background: #fff; border-color: var(--gc); box-shadow: 0 0 0 4px var(--gc-soft); }
.pick input:checked + .pick-card .tick { opacity: 1; }

.step-nav {
    position: sticky; top: 0; z-index: 15;
    display: flex; gap: 0.4rem; overflow-x: auto; scrollbar-width: none;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 0.75rem; padding: 0.5rem;
    margin-bottom: 1rem;
}
.step-nav::-webkit-scrollbar { display: none; }
.step-chip {
    display: inline-flex; align-items: center; gap: 0.45rem; white-space: nowrap;
    padding: 0.45rem 0.9rem; border-radius: 0.6rem;
    font-size: 0.78rem; font-weight: 600; color: #64748B;
    border: 1px solid transparent;
    text-decoration: none; cursor: pointer; background: transparent;
}
.step-chip:hover { color: #1E293B; background: #F1F5F9; }
.step-chip .n {
    width: 1.4rem; height: 1.4rem; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center;
    border-radius: 9999px; background: #E2E8F0; color: #64748B;
    font-size: 0.7rem; font-weight: 700;
}
.step-chip.active { background: #fff; color: var(--gc); border-color: var(--gc); }
.step-chip.active .n { background: var(--gc); color: #fff; }

.summary-row { display: flex; gap: 0.6rem; padding: 0.5rem 0; border-bottom: 1px dashed #E2E8F0; }
.summary-row:last-child { border-bottom: none; }
.summary-row .k { flex-shrink: 0; width: 6.5rem; font-size: 0.75rem; color: #64748B; }
.summary-row .v { font-size: 0.8rem; color: #0F172A; font-weight: 500; min-width: 0; word-break: break-word; }
.summary-row .v.placeholder { color: #94A3B8; font-weight: 400; font-style: italic; }

.form-actions {
    margin-top: 1.25rem; padding: 0.9rem 1.15rem;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 1rem;
    display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap;
}
.form-actions .status { font-size: 0.76rem; color: #64748B; display: inline-flex; align-items: center; gap: 0.4rem; }
.form-actions .status b { color: #DC2626; }
.form-actions .btn-row { display: flex; align-items: center; gap: 0.5rem; }

.alert-box {
    display: flex; align-items: flex-start; gap: 0.6rem;
    border-radius: 10px; padding: 0.7rem 0.9rem; font-size: 0.82rem;
    border: 1px solid; margin-bottom: 1rem;
}
.alert-box.error { background: #FEF2F2; border-color: #FECACA; color: #B91C1C; }
.alert-box.info  { background: #EFF6FF; border-color: #BFDBFE; color: #1D4ED8; }
.alert-box.warn  { background: #FFFBEB; border-color: #FDE68A; color: #B45309; }

::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-thumb { background: #94a3b8; border-radius: 10px; }

@media (prefers-reduced-motion: reduce) {
    * { animation: none !important; transition: none !important; }
}
@media (max-width: 640px) {
    .fsec { padding: 1rem 0.9rem 1.1rem; }
    .pick-grid { grid-template-columns: 1fr 1fr; gap: 0.5rem; }
    .pick-card { padding: 0.6rem; gap: 0.5rem; }
    .pick-card .dot { width: 2rem; height: 2rem; }
    .pick-card b { font-size: 0.78rem; }
    .btn-action { width: 44px; height: 44px; }
}
</style>
</head>
<body>

<!-- Drawer + sidebar -->
<div class="eoc-backdrop" id="eocBackdrop" hidden></div>
<aside class="eoc-side" id="eocSide" aria-label="เมนูด้านข้าง">
    <div class="eoc-side-top">
        <span><i class="fas fa-bars" aria-hidden="true"></i>&nbsp; เมนู</span>
        <button type="button" id="eocNavClose" aria-label="ปิดเมนู"><i class="fas fa-xmark" aria-hidden="true"></i></button>
    </div>
    <?php
        $sidebar_drawer = true;
        $sidebar_skip_assets = true;
        include __DIR__ . '/sidebar_eoc.php';
    ?>
</aside>

<div class="main-content min-h-screen flex flex-col">

    <!-- Header -->
    <header class="gradient-bg text-white shadow-lg lg:sticky lg:top-0 z-40" style="padding-top: env(safe-area-inset-top, 0px);">
        <div class="py-3 lg:py-4 header-safe">
            <div class="flex items-center justify-between gap-3">
                <div class="flex items-center gap-3 min-w-0">
                    <button type="button" id="eocNavToggle" aria-controls="eocSide" aria-expanded="false" aria-label="เปิดเมนูนำทาง"
                            class="lg:hidden glass-effect rounded-lg w-11 h-11 flex-none flex items-center justify-center">
                        <i class="fas fa-bars" aria-hidden="true"></i>
                    </button>
                    <div class="glass-effect rounded-xl p-2.5 flex-none hidden sm:block">
                        <i class="<?= eoc_h($group_icon) ?> text-xl" style="color: <?= eoc_h($group_color) ?>" aria-hidden="true"></i>
                    </div>
                    <div class="min-w-0">
                        <h1 class="text-base sm:text-xl font-bold tracking-tight truncate">
                            <?= $is_edit_mode ? 'แก้ไขข้อมูลการช่วยเหลือ' : 'บันทึกข้อมูลการช่วยเหลือ' ?>
                        </h1>
                        <p class="text-gray-300 text-xs hidden sm:block truncate">VOC – Vulnerable Operations Center</p>
                    </div>
                </div>
                <div class="flex items-center gap-2 flex-none">
                    <div class="hidden md:flex items-center gap-3 glass-effect rounded-lg px-3 py-1.5 max-w-[16rem]">
                        <div class="w-9 h-9 flex-none bg-blue-600 rounded-full flex items-center justify-center">
                            <i class="fas fa-user-md text-white text-sm" aria-hidden="true"></i>
                        </div>
                        <div class="text-sm min-w-0">
                            <div class="font-semibold truncate"><?= eoc_h($user_name) ?></div>
                            <div class="text-gray-300 text-xs truncate"><?= eoc_h($status_user) ?> | <?= eoc_h($user_hospcode) ?></div>
                        </div>
                    </div>
                    <a href="../../logout.php" aria-label="ออกจากระบบ" title="ออกจากระบบ"
                       class="btn-action bg-red-600">
                        <i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
            <div class="mt-2 pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 text-xs text-gray-300">
                <div class="hidden lg:flex items-center gap-4">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-tag" aria-hidden="true"></i>
                        <span>กลุ่ม: <?= eoc_h($group_name) ?> (<?= eoc_h($group_code) ?>)</span>
                    </div>
                </div>
                <div class="flex flex-wrap items-center gap-x-4 gap-y-1">
                    <div class="flex items-center gap-2">
                        <i class="fas fa-clock" aria-hidden="true"></i>
                        <span id="current-time"><?= date('H:i') ?></span>
                    </div>
                    <div class="flex items-center gap-2">
                        <i class="fas fa-calendar" aria-hidden="true"></i>
                        <span><?= date('d/m/Y') ?></span>
                    </div>
                    <div class="flex items-center gap-2">
                        <i class="fas fa-hourglass-half" aria-hidden="true"></i>
                        <span>หมดเขต: <span id="timeout-timer" class="font-mono font-semibold"><?= $time_left_formatted ?></span></span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="p-4 sm:p-6 lg:p-8 main-safe flex-1">
        <div class="max-w-6xl mx-auto">

            <!-- Flash -->
            <?php if ($__success_msg): ?>
                <div class="alert-box info">
                    <i class="fas fa-circle-check mt-0.5"></i>
                    <div><?= eoc_h($__success_msg) ?></div>
                </div>
            <?php endif; ?>
            <?php if ($__error_msg): ?>
                <div class="alert-box error">
                    <i class="fas fa-circle-exclamation mt-0.5"></i>
                    <div><?= eoc_h($__error_msg) ?></div>
                </div>
            <?php endif; ?>
            <?php if (!empty($errors['_form'])): ?>
                <div class="alert-box error">
                    <i class="fas fa-circle-exclamation mt-0.5"></i>
                    <div><?= eoc_h($errors['_form']) ?></div>
                </div>
            <?php endif; ?>

            <!-- Breadcrumb + Back -->
            <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
                <nav class="text-xs sm:text-sm text-gray-500 flex items-center gap-1 flex-wrap">
                    <a href="<?= eoc_h($pick_patient_url) ?>" class="hover:text-gray-800">ทะเบียนผู้ป่วย</a>
                    <i class="fas fa-chevron-right text-[10px] text-gray-400"></i>
                    <a href="<?= eoc_h($service_url) ?>" class="hover:text-gray-800"><?= eoc_h($patient['name'] ?? $idcard) ?></a>
                    <i class="fas fa-chevron-right text-[10px] text-gray-400"></i>
                    <span class="text-gray-700 font-semibold"><?= $is_edit_mode ? 'แก้ไข' : 'บันทึก' ?>บริการ</span>
                </nav>
                <a href="<?= eoc_h($service_url) ?>" class="btn-action btn-back" title="กลับหน้าประวัติ">
                    <i class="fas fa-arrow-left" aria-hidden="true"></i>
                </a>
            </div>

            <!-- Alert edit mode -->
            <?php if ($is_edit_mode): ?>
                <div class="alert-box warn">
                    <i class="fas fa-pen-to-square mt-0.5"></i>
                    <div>
                        <strong>โหมดแก้ไข</strong> — กำลังแก้ไขรายการเลขที่ <strong><?= eoc_h($edit_service_no) ?></strong>
                        ของผู้ป่วย <strong><?= eoc_h($patient['name'] ?? $idcard) ?></strong>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Patient bar -->
            <section class="info-card p-4 sm:p-5 mb-4">
                <div class="patient-bar">
                    <div class="av"><i class="<?= eoc_h($group_icon) ?>"></i></div>
                    <div class="flex-1 min-w-[200px]">
                        <div class="flex flex-wrap items-center gap-2">
                            <h2 class="text-lg sm:text-xl font-bold text-gray-800"><?= eoc_h($patient['name'] ?? $idcard) ?></h2>
                            <span class="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full"
                                  style="background: var(--gc-soft); color: var(--gc);">
                                <i class="<?= eoc_h($group_icon) ?>"></i><?= eoc_h($group_name) ?>
                            </span>
                            <?php if (!empty($patient['emergency_name'])): ?>
                                <span class="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-red-50 text-red-600 border border-red-200">
                                    <i class="fas fa-triangle-exclamation"></i><?= eoc_h($patient['emergency_name']) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="meta">
                            <span><i class="fas fa-id-card"></i><?= eoc_h($idcard) ?></span>
                            <span><i class="fas fa-venus-mars"></i><?= eoc_h($patient['gender'] ?? '-') ?></span>
                            <span><i class="fas fa-cake-candles"></i><?= eoc_h($patient['age'] ?? '-') ?> ปี</span>
                            <span><i class="fas fa-hospital"></i><?= eoc_h($patient['hospital'] ?? $patient['hospcode'] ?? '-') ?></span>
                            <?php if (!empty($patient['patient_phone'])): ?>
                                <span><i class="fas fa-phone"></i><?= eoc_h($patient['patient_phone']) ?></span>
                            <?php endif; ?>
                            <span><i class="fas fa-clipboard-list"></i>มีประวัติ <?= $existing_count ?> รายการ</span>
                        </div>
                    </div>
                    <div class="flex flex-wrap items-center gap-2">
                        <a href="<?= eoc_h($service_url) ?>" class="btn-action btn-info" title="ดูประวัติการช่วยเหลือ">
                            <i class="fas fa-clock-rotate-left"></i>
                        </a>
                        <a href="<?= eoc_h($pick_patient_url) ?>" class="btn-action btn-back" title="เปลี่ยนผู้ป่วย">
                            <i class="fas fa-user-pen"></i>
                        </a>
                    </div>
                </div>
            </section>

            <!-- Step nav -->
            <nav class="step-nav" aria-label="ขั้นตอนการกรอกข้อมูล">
                <button type="button" class="step-chip active" data-jump="sec1"><span class="n">1</span> ข้อมูลคำขอ</button>
                <button type="button" class="step-chip" data-jump="sec2"><span class="n">2</span> การดำเนินการ</button>
                <button type="button" class="step-chip" data-jump="sec3"><span class="n">3</span> ผลการบริการ</button>
                <button type="button" class="step-chip" data-jump="sec4"><span class="n">4</span> ตรวจสอบ</button>
            </nav>

            <!-- Form -->
            <form method="POST" id="addServiceForm" novalidate autocomplete="off">
                <input type="hidden" name="form_token" value="<?= eoc_h($form_token) ?>">
                <?php if ($is_edit_mode): ?>
                    <input type="hidden" name="edit" value="<?= eoc_h($edit_service_no) ?>">
                <?php endif; ?>

                <!-- Section 1 -->
                <section class="fsec" id="sec1">
                    <div class="fsec-head">
                        <div class="fnum">1</div>
                        <div>
                            <h4>ข้อมูลคำขอความช่วยเหลือ</h4>
                            <p>ระบุว่าผู้ป่วยต้องการรับความช่วยเหลือด้านใด</p>
                        </div>
                    </div>

                    <div>
                        <div class="fld-label">
                            <span class="l"><i class="fas fa-layer-group"></i>ประเภทการร้องขอ</span>
                            <span class="req"><i class="fas fa-asterisk"></i>จำเป็น</span>
                        </div>
                        <div class="pick-grid" id="requestTypeGrid" role="radiogroup">
                            <?php foreach ($request_types as $rt):
                                $rt_code = (string)$rt['request_code'];
                                $rt_info = $request_type_index[$rt_code] ?? ['name' => $rt_code, 'icon' => 'fas fa-file-medical', 'color' => '#3B82F6'];
                            ?>
                                <label class="pick">
                                    <input type="radio" name="request_type" value="<?= eoc_h($rt_code) ?>"
                                           data-color="<?= eoc_h($rt_info['color']) ?>"
                                           <?= ($form['request_type'] === $rt_code) ? 'checked' : '' ?> required>
                                    <span class="pick-card">
                                        <span class="dot" style="color: <?= eoc_h($rt_info['color']) ?>;">
                                            <i class="<?= eoc_h($rt_info['icon']) ?>"></i>
                                        </span>
                                        <span class="txt"><b><?= eoc_h($rt_info['name']) ?></b></span>
                                        <i class="fas fa-circle-check tick"></i>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <?php if (isset($errors['request_type'])): ?>
                            <div class="err-msg"><i class="fas fa-circle-exclamation"></i><?= eoc_h($errors['request_type']) ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="mt-5">
                        <div class="fld-label">
                            <span class="l"><i class="fas fa-comment-dots"></i>รายละเอียดที่ต้องการรับความช่วยเหลือ</span>
                            <span class="req"><i class="fas fa-asterisk"></i>จำเป็น</span>
                        </div>
                        <textarea name="message" id="message" rows="4" required maxlength="<?= EOC_MAX_MESSAGE ?>"
                                  class="fld <?= isset($errors['message']) ? 'is-error' : '' ?>"
                                  placeholder="เช่น ผู้ป่วยต้องการนัดหมอตามทางเดิน มีอาการเจ็บหน้าอก ไม่มีคนพาไปโรงพยาบาล..."><?= eoc_h($form['message']) ?></textarea>
                        <div class="char-row">
                            <span class="fld-hint" style="margin-top:0">
                                <i class="fas fa-lightbulb"></i>
                                <span>ระบุอาการ เวลา และสิ่งที่ต้องการให้ชัดเจน</span>
                            </span>
                            <span class="char-count" id="messageCount">0 / <?= EOC_MAX_MESSAGE ?></span>
                        </div>
                        <?php if (isset($errors['message'])): ?>
                            <div class="err-msg"><i class="fas fa-circle-exclamation"></i><?= eoc_h($errors['message']) ?></div>
                        <?php endif; ?>
                    </div>
                </section>

                <!-- Section 2 -->
                <section class="fsec" id="sec2">
                    <div class="fsec-head">
                        <div class="fnum">2</div>
                        <div>
                            <h4>ข้อมูลการดำเนินการ</h4>
                            <p>บันทึกว่าใครเป็นผู้ดำเนินการ ที่ไหน และเมื่อใด</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div>
                            <div class="fld-label">
                                <span class="l"><i class="fas fa-calendar-day"></i>วันที่ให้บริการ</span>
                                <span class="opt">ปรับได้</span>
                            </div>
                            <input type="date" name="service_date" id="service_date"
                                   value="<?= eoc_h($form['service_date']) ?>"
                                   max="<?= date('Y-m-d') ?>" class="fld">
                        </div>
                        <div>
                            <div class="fld-label">
                                <span class="l"><i class="fas fa-user-md"></i>ผู้ให้บริการ / ผู้รับเรื่อง</span>
                                <span class="opt">ไม่บังคับ</span>
                            </div>
                            <input type="text" name="service_provider" id="service_provider" maxlength="255"
                                   value="<?= eoc_h($form['service_provider']) ?>"
                                   class="fld <?= isset($errors['service_provider']) ? 'is-error' : '' ?>"
                                   placeholder="เว้นว่าง = ใช้ชื่อผู้บันทึก (<?= eoc_h($user_name) ?>)">
                            <?php if (isset($errors['service_provider'])): ?>
                                <div class="err-msg"><i class="fas fa-circle-exclamation"></i><?= eoc_h($errors['service_provider']) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div id="locationBlock" class="mt-5" style="display:none;">
                        <div class="fld-label">
                            <span class="l"><i class="fas fa-location-dot"></i><span id="locationLabel">สถานที่ดำเนินการ</span></span>
                            <span class="req"><i class="fas fa-asterisk"></i>จำเป็น</span>
                        </div>
                        <div class="fld-wrap">
                            <select name="service_location" id="service_location" class="fld <?= isset($errors['service_location']) ? 'is-error' : '' ?>">
                                <option value="">-- เลือกสถานที่ --</option>
                                <?php foreach ($referral_centers as $rc): ?>
                                    <option value="<?= eoc_h($rc['center_name']) ?>" <?= ($form['service_location'] === $rc['center_name']) ? 'selected' : '' ?>>
                                        <?= eoc_h($rc['center_name']) ?><?= !empty($rc['phone']) ? ' (โทร. ' . eoc_h($rc['phone']) . ')' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                                <option value="other" <?= ($form['service_location'] === 'other') ? 'selected' : '' ?>>อื่นๆ (โปรดระบุ)</option>
                            </select>
                            <i class="fas fa-chevron-down chev"></i>
                        </div>
                        <div id="locationOtherWrap" class="mt-3" style="display:none;">
                            <input type="text" name="service_location_other" id="service_location_other" maxlength="255"
                                   value="<?= eoc_h($form['service_location_other']) ?>"
                                   class="fld <?= isset($errors['service_location_other']) ? 'is-error' : '' ?>"
                                   placeholder="ระบุชื่อสถานที่หรือศูนย์">
                        </div>
                    </div>

                    <div class="mt-5">
                        <div class="fld-label">
                            <span class="l"><i class="fas fa-clipboard-list"></i>รายละเอียดการบริการ</span>
                            <span class="opt">ไม่บังคับ</span>
                        </div>
                        <textarea name="service_detail" id="service_detail" rows="3" maxlength="<?= EOC_MAX_MESSAGE ?>"
                                  class="fld <?= isset($errors['service_detail']) ? 'is-error' : '' ?>"
                                  placeholder="เช่น นัดหมอผิวหนังวันที่ 30/09/2569 เวลา 10:00 น...."><?= eoc_h($form['service_detail']) ?></textarea>
                        <div class="char-row">
                            <span></span>
                            <span class="char-count" id="detailCount">0 / <?= EOC_MAX_MESSAGE ?></span>
                        </div>
                    </div>
                </section>

                <!-- Section 3 -->
                <section class="fsec" id="sec3">
                    <div class="fsec-head">
                        <div class="fnum">3</div>
                        <div>
                            <h4>ผลการบริการและสถานะ</h4>
                            <p>เลือกผลการบริการ — ระบบจะแปรผลสถานะให้อัตโนมัติ</p>
                        </div>
                    </div>

                    <div>
                        <div class="fld-label">
                            <span class="l"><i class="fas fa-clipboard-check"></i>ผลการบริการ</span>
                            <span class="req"><i class="fas fa-asterisk"></i>จำเป็น</span>
                        </div>
                        <div class="pick-grid" role="radiogroup" aria-label="ผลการบริการ">
                            <?php foreach ($result_labels as $rkey => $rinfo): ?>
                                <label class="pick">
                                    <input type="radio" name="service_result" value="<?= eoc_h($rkey) ?>"
                                           <?= ($form['service_result'] === $rkey) ? 'checked' : '' ?> required>
                                    <span class="pick-card">
                                        <span class="dot" style="color: <?= eoc_h($rinfo['color']) ?>;">
                                            <i class="<?= eoc_h($rinfo['icon']) ?>"></i>
                                        </span>
                                        <span class="txt"><b><?= eoc_h($rinfo['text']) ?></b></span>
                                        <i class="fas fa-circle-check tick"></i>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- สถานะ read-only -->
                    <div class="mt-6">
                        <div class="fld-label">
                            <span class="l"><i class="fas fa-flag"></i>สถานะการดำเนินการ</span>
                            <span class="opt"><i class="fas fa-wand-magic-sparkles"></i>ระบบกำหนดอัตโนมัติ</span>
                        </div>

                        <input type="hidden" name="status" id="status_hidden" value="<?= eoc_h($form['status']) ?>">

                        <div id="statusDisplay"
                             class="flex items-center gap-3 px-4 py-3 rounded-xl border-2"
                             style="background: <?= $__status_is_success ? '#F0FDF4' : '#FEF2F2' ?>;
                                    border-color: <?= $__status_is_success ? '#86EFAC' : '#FCA5A5' ?>;
                                    color: <?= $__status_is_success ? '#166534' : '#991B1B' ?>;">
                            <div class="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                                 id="statusIconWrap"
                                 style="background: <?= $__status_is_success ? '#10B981' : '#DC2626' ?>;">
                                <i id="statusIcon" class="<?= $__status_is_success ? 'fas fa-circle-check' : 'fas fa-spinner' ?> text-white"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="text-xs font-semibold uppercase tracking-wide opacity-70">สถานะ</div>
                                <div class="font-bold text-base" id="statusText">
                                    <?= $__status_is_success ? 'เสร็จสิ้น' : 'กำลังดำเนินการ' ?>
                                </div>
                            </div>
                            <div class="ml-auto text-xs opacity-75 hidden sm:flex items-center gap-1.5">
                                <i class="fas fa-info-circle"></i>
                                <span>แปรผลจากผลการบริการ</span>
                            </div>
                        </div>

                        <div class="fld-hint mt-2">
                            <i class="fas fa-lightbulb"></i>
                            <span>
                                <strong>สำเร็จ</strong> → สถานะ <span class="text-green-600 font-semibold">เสร็จสิ้น</span> (พื้นหลังเขียว) &nbsp;|&nbsp;
                                <strong>รอดำเนินการ / สำเร็จบางส่วน / ไม่สำเร็จ</strong> → สถานะ <span class="text-red-600 font-semibold">กำลังดำเนินการ</span> (พื้นหลังแดง)
                            </span>
                        </div>
                    </div>
                </section>

                <!-- Section 4 -->
                <section class="fsec" id="sec4">
                    <div class="fsec-head">
                        <div class="fnum">4</div>
                        <div>
                            <h4>ตรวจสอบข้อมูลก่อนบันทึก</h4>
                            <p>สรุปข้อมูลแบบเรียลไทม์ — ตรวจสอบให้ถูกต้องก่อนกดบันทึก</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
                        <div class="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                            <div class="summary-row"><span class="k">ผู้ป่วย</span><span class="v"><?= eoc_h($patient['name'] ?? $idcard) ?> (<?= eoc_h($idcard) ?>)</span></div>
                            <div class="summary-row"><span class="k">กลุ่ม</span><span class="v"><?= eoc_h($group_name) ?></span></div>
                            <div class="summary-row"><span class="k">ประเภท</span><span class="v placeholder" id="sumType">ยังไม่ได้เลือก</span></div>
                            <div class="summary-row"><span class="k">วันที่</span><span class="v" id="sumDate">-</span></div>
                        </div>
                        <div class="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                            <div class="summary-row"><span class="k">ผู้ให้บริการ</span><span class="v" id="sumProvider">-</span></div>
                            <div class="summary-row"><span class="k">สถานที่</span><span class="v placeholder" id="sumLocation">ไม่ระบุ</span></div>
                            <div class="summary-row"><span class="k">ผล/สถานะ</span><span class="v" id="sumStatus">-</span></div>
                            <div class="summary-row"><span class="k">ช่องทาง</span><span class="v"><?= $is_edit_mode ? 'แก้ไขโดยเจ้าหน้าที่ (' . eoc_h($edit_service_no) . ')' : 'บันทึกโดยเจ้าหน้าที่ (ใหม่)' ?></span></div>
                        </div>
                    </div>

                    <div class="mt-4 rounded-xl border border-slate-200 bg-white p-4">
                        <div class="text-xs font-semibold text-slate-500 mb-1.5">
                            <i class="fas fa-comment-dots mr-1"></i>รายละเอียดที่ต้องการรับความช่วยเหลือ
                        </div>
                        <p class="text-sm text-slate-700 whitespace-pre-wrap break-words" id="sumMessage">ยังไม่ได้กรอกรายละเอียด</p>
                    </div>
                </section>

                <!-- Form actions — ปุ่มไอคอนเท่านั้น -->
                <div class="form-actions">
                    <div class="status">
                        <i class="fas fa-shield-halved"></i>
                        <span>ช่องที่ยังต้องกรอก <b id="requiredLeft">2</b> ช่อง</span>
                    </div>
                    <div class="btn-row">
                        <button type="button" class="btn-action btn-lg btn-back" id="cancelBtn" title="ยกเลิก (Esc)" aria-label="ยกเลิก">
                            <i class="fas fa-xmark"></i>
                        </button>
                        <button type="submit" class="btn-action btn-lg btn-service" id="submitBtn" title="<?= $is_edit_mode ? 'บันทึกการแก้ไข (Ctrl+Enter)' : 'บันทึกข้อมูล (Ctrl+Enter)' ?>" aria-label="บันทึก">
                            <i class="fas fa-floppy-disk"></i>
                        </button>
                    </div>
                </div>
            </form>

            <div class="h-4"></div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 text-white py-6 mt-8" style="padding-bottom: calc(1.5rem + env(safe-area-inset-bottom, 0px));">
        <div class="px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
                <div class="flex items-center gap-4">
                    <div class="w-10 h-10 flex-none bg-blue-600 rounded-lg flex items-center justify-center">
                        <i class="fas fa-hand-holding-heart text-white"></i>
                    </div>
                    <div class="text-left">
                        <div class="font-semibold text-base">VOC Thepha Care</div>
                        <div class="text-gray-400 text-sm">Vulnerable Operations Center</div>
                        <div class="text-gray-500 text-xs mt-1">ศูนย์ดูแลกลุ่มเปราะบาง ครอบคลุมทุกสถานการณ์</div>
                    </div>
                </div>
                <div class="flex flex-wrap items-center justify-center gap-x-6 gap-y-1 text-gray-400 text-sm">
                    <div class="flex items-center gap-2"><i class="fas fa-copyright"></i><span><?= (int)date('Y') + 543 ?> Thepha Care</span></div>
                    <div class="flex items-center gap-2"><i class="fas fa-heart text-red-400"></i><span>ดูแลครบวงจร ในจุดเดียว</span></div>
                </div>
            </div>
        </div>
    </footer>
</div>

<script>
(function(){
    'use strict';

    var NEED_LOCATION = <?= $need_location_json ?: '[]' ?>;
    var MAXLEN        = <?= (int)EOC_MAX_MESSAGE ?>;
    var DRAFT_KEY     = 'eoc_add_draft_<?= eoc_h($idcard) ?>_<?= eoc_h($group_code) ?><?= $is_edit_mode ? '_edit_' . eoc_h($edit_service_no) : '' ?>';
    var BACK_URL      = <?= json_encode($service_url, JSON_UNESCAPED_UNICODE) ?>;
    var GC            = <?= json_encode($group_color) ?>;

    var $  = function(s){ return document.querySelector(s); };
    var $$ = function(s){ return Array.prototype.slice.call(document.querySelectorAll(s)); };

    var form = $('#addServiceForm');
    if (!form) return;

    var messageEl    = $('#message');
    var detailEl     = $('#service_detail');
    var dateEl       = $('#service_date');
    var providerEl   = $('#service_provider');
    var locationEl   = $('#service_location');
    var locOtherEl   = $('#service_location_other');
    var locBlock     = $('#locationBlock');
    var locOtherWrap = $('#locationOtherWrap');
    var locLabel     = $('#locationLabel');
    var cancelBtn    = $('#cancelBtn');
    var submitBtn    = $('#submitBtn');
    var reqLeftEl    = $('#requiredLeft');

    var resultLabels = <?= json_encode($result_labels, JSON_UNESCAPED_UNICODE) ?>;

    // Time update
    (function(){
        var t = document.getElementById('current-time');
        function upd(){
            if (t) t.textContent = new Date().toLocaleTimeString('th-TH', { hour:'2-digit', minute:'2-digit', hour12:false });
        }
        upd(); setInterval(upd, 30000);
    })();

    // Drawer
    (function(){
        var side = $('#eocSide'), backdrop = $('#eocBackdrop'),
            openBtn = $('#eocNavToggle'), closeBtn = $('#eocNavClose'),
            desktop = window.matchMedia('(min-width: 1024px)');
        if (!side || !openBtn) return;
        function setDrawer(open){
            side.classList.toggle('open', open);
            backdrop.hidden = !open;
            document.body.classList.toggle('nav-open', open);
            openBtn.setAttribute('aria-expanded', open);
            if (open && closeBtn) closeBtn.focus();
        }
        openBtn.addEventListener('click', function(){ setDrawer(!side.classList.contains('open')); });
        if (closeBtn) closeBtn.addEventListener('click', function(){ setDrawer(false); openBtn.focus(); });
        if (backdrop) backdrop.addEventListener('click', function(){ setDrawer(false); });
        side.addEventListener('click', function(ev){ if (ev.target.closest('a[href]')) setDrawer(false); });
        document.addEventListener('keydown', function(ev){
            if (ev.key === 'Escape' && side.classList.contains('open')) { setDrawer(false); openBtn.focus(); }
        });
        var onDesk = function(ev){ if (ev.matches) setDrawer(false); };
        if (desktop.addEventListener) desktop.addEventListener('change', onDesk);
        else desktop.addListener(onDesk);
    })();

    // Counter
    function updateCounter(field, counterId){
        var box = document.getElementById(counterId);
        if (!box || !field) return;
        var len = field.value.length;
        box.textContent = len + ' / ' + MAXLEN;
        box.classList.remove('warn','over');
        if (len > MAXLEN) box.classList.add('over');
        else if (len > MAXLEN * 0.9) box.classList.add('warn');
    }
    function bindCounter(field, cid){
        if (!field) return;
        updateCounter(field, cid);
        field.addEventListener('input', function(){ updateCounter(field, cid); });
    }
    bindCounter(messageEl, 'messageCount');
    bindCounter(detailEl, 'detailCount');

    // Location
    function getSelectedType(){
        var c = form.querySelector('input[name="request_type"]:checked');
        return c ? c.value : '';
    }
    function syncOtherLocation(){
        var isOther = locationEl && locationEl.value === 'other';
        if (locOtherWrap) locOtherWrap.style.display = isOther ? 'block' : 'none';
        if (locOtherEl) locOtherEl.required = !!isOther;
        if (!isOther && locOtherEl) locOtherEl.value = '';
    }
    function syncLocationField(){
        var type = getSelectedType();
        var need = NEED_LOCATION.indexOf(type) !== -1;
        if (locBlock) locBlock.style.display = need ? 'block' : 'none';
        if (locationEl) locationEl.required = need;
        if (need && locLabel) {
            locLabel.textContent = (type === 'shelter') ? 'ศูนย์พักพิง / สถานที่รับส่งต่อ' : 'สถานที่ปลายทาง';
        } else if (locationEl) {
            locationEl.value = '';
            if (locOtherEl) locOtherEl.value = '';
        }
        syncOtherLocation();
    }
    $$('input[name="request_type"]').forEach(function(r){ r.addEventListener('change', syncLocationField); });
    if (locationEl) locationEl.addEventListener('change', syncOtherLocation);
    syncLocationField();

    // Auto-map status
    function syncStatusFromResult(){
        var resultInput = form.querySelector('input[name="service_result"]:checked');
        var result      = resultInput ? resultInput.value : 'pending';
        var isSuccess   = (result === 'success');

        var hidden   = document.getElementById('status_hidden');
        var display  = document.getElementById('statusDisplay');
        var iconWrap = document.getElementById('statusIconWrap');
        var icon     = document.getElementById('statusIcon');
        var text     = document.getElementById('statusText');

        if (hidden) hidden.value = isSuccess ? 'completed' : 'in_progress';

        if (display) {
            display.style.background  = isSuccess ? '#F0FDF4' : '#FEF2F2';
            display.style.borderColor = isSuccess ? '#86EFAC' : '#FCA5A5';
            display.style.color       = isSuccess ? '#166534' : '#991B1B';
        }
        if (iconWrap) iconWrap.style.background = isSuccess ? '#10B981' : '#DC2626';
        if (icon)     icon.className = isSuccess ? 'fas fa-circle-check text-white' : 'fas fa-spinner text-white';
        if (text)     text.textContent = isSuccess ? 'เสร็จสิ้น' : 'กำลังดำเนินการ';
    }
    $$('input[name="service_result"]').forEach(function(radio){
        radio.addEventListener('change', function(){
            syncStatusFromResult();
            refreshSummary();
            saveDraft();
        });
    });

    // Summary
    function setText(id, text, ph){
        var el = document.getElementById(id);
        if (!el) return;
        var empty = !text || !String(text).trim();
        el.textContent = empty ? (ph || '-') : text;
        el.classList.toggle('placeholder', empty);
    }
    function formatThaiDate(v){
        if (!v) return '';
        var p = String(v).split('-');
        if (p.length !== 3) return v;
        return p[2] + '/' + p[1] + '/' + (Number(p[0]) + 543);
    }
    function labelFromCard(input){
        if (!input) return '';
        var card = input.closest('.pick');
        var b = card ? card.querySelector('b') : null;
        return b ? b.textContent.trim() : input.value;
    }
    function refreshSummary(){
        setText('sumType', labelFromCard(form.querySelector('input[name="request_type"]:checked')), 'ยังไม่ได้เลือก');
        setText('sumDate', formatThaiDate(dateEl ? dateEl.value : ''), '-');
        setText('sumProvider', (providerEl && providerEl.value.trim()) || 'ไม่ระบุ (จะใช้ชื่อผู้บันทึก)', '-');

        var locText = '';
        if (locationEl && locationEl.value) {
            if (locationEl.value === 'other') locText = (locOtherEl && locOtherEl.value.trim()) || 'อื่นๆ (ยังไม่ระบุ)';
            else locText = locationEl.options[locationEl.selectedIndex] ? locationEl.options[locationEl.selectedIndex].text : locationEl.value;
        }
        setText('sumLocation', locText, 'ไม่ระบุ');

        var r = form.querySelector('input[name="service_result"]:checked');
        var bits = [];
        if (r && resultLabels[r.value]) {
            bits.push(resultLabels[r.value].text);
            bits.push(r.value === 'success' ? 'เสร็จสิ้น' : 'กำลังดำเนินการ');
        }
        setText('sumStatus', bits.join(' · '), '-');

        setText('sumMessage', (messageEl && messageEl.value.trim()) || '', 'ยังไม่ได้กรอกรายละเอียด');

        var missing = 0;
        if (!getSelectedType()) missing++;
        if (!(messageEl && messageEl.value.trim())) missing++;
        if (locationEl && locationEl.required) {
            if (!locationEl.value) missing++;
            else if (locationEl.value === 'other' && !(locOtherEl && locOtherEl.value.trim())) missing++;
        }
        if (reqLeftEl) {
            reqLeftEl.textContent = String(missing);
            reqLeftEl.style.color = missing > 0 ? '#DC2626' : '#059669';
        }
    }

    // Validate
    function markError(el, on){ if (el) el.classList.toggle('is-error', !!on); }
    function focusFirstError(target){
        if (!target) return;
        try {
            target.scrollIntoView({ behavior: 'smooth', block: 'center' });
            if (typeof target.focus === 'function') target.focus({ preventScroll: true });
        } catch (e) { target.scrollIntoView(); }
    }
    function validate(){
        var firstError = null;
        var type = getSelectedType();
        var msg = messageEl ? messageEl.value.trim() : '';

        markError(messageEl, false);
        if (!type && !firstError) firstError = $('#requestTypeGrid');

        if (!msg || msg.length > MAXLEN) {
            markError(messageEl, true);
            if (!firstError) firstError = messageEl;
        }

        markError(locationEl, false);
        markError(locOtherEl, false);
        if (locationEl && locationEl.required) {
            if (!locationEl.value) {
                markError(locationEl, true);
                if (!firstError) firstError = locationEl;
            } else if (locationEl.value === 'other' && !(locOtherEl && locOtherEl.value.trim())) {
                markError(locOtherEl, true);
                if (!firstError) firstError = locOtherEl;
            }
        }

        if (!form.querySelector('input[name="service_result"]:checked') && !firstError) {
            firstError = form.querySelector('input[name="service_result"]');
        }

        return firstError;
    }

    // Draft
    function collectDraft(){
        return {
            request_type: getSelectedType(),
            message: messageEl ? messageEl.value : '',
            service_detail: detailEl ? detailEl.value : '',
            service_provider: providerEl ? providerEl.value : '',
            service_date: dateEl ? dateEl.value : '',
            service_location: locationEl ? locationEl.value : '',
            service_location_other: locOtherEl ? locOtherEl.value : '',
            service_result: (form.querySelector('input[name="service_result"]:checked') || {}).value || '',
            saved_at: new Date().toISOString()
        };
    }
    function saveDraft(){
        try {
            var d = collectDraft();
            if (!d.request_type && !d.message.trim() && !d.service_detail.trim()) return;
            sessionStorage.setItem(DRAFT_KEY, JSON.stringify(d));
        } catch (e) {}
    }
    function clearDraft(){
        try { sessionStorage.removeItem(DRAFT_KEY); } catch (e) {}
    }
    function applyDraft(d){
        if (d.request_type) {
            var radio = form.querySelector('input[name="request_type"][value="' + d.request_type + '"]');
            if (radio) radio.checked = true;
        }
        if (d.message && messageEl) messageEl.value = d.message;
        if (d.service_detail && detailEl) detailEl.value = d.service_detail;
        if (d.service_provider && providerEl) providerEl.value = d.service_provider;
        if (d.service_date && dateEl) dateEl.value = d.service_date;
        if (d.service_result) {
            var rr = form.querySelector('input[name="service_result"][value="' + d.service_result + '"]');
            if (rr) rr.checked = true;
        }
        syncLocationField();
        if (d.service_location && locationEl) locationEl.value = d.service_location;
        syncOtherLocation();
        if (d.service_location_other && locOtherEl) locOtherEl.value = d.service_location_other;
        updateCounter(messageEl, 'messageCount');
        updateCounter(detailEl, 'detailCount');
        syncStatusFromResult();
    }

    // Submit / Cancel
    var submitting = false;
    var allowUnload = false;

    function doSubmit(){
        if (submitting) return;
        syncStatusFromResult();

        var bad = validate();
        if (bad) {
            focusFirstError(bad);
            Swal.fire({
                icon: 'warning', title: 'ข้อมูลยังไม่ครบ',
                html: bad.id === 'requestTypeGrid'
                    ? 'กรุณาเลือก <strong>ประเภทการร้องขอ</strong><br>และระบุ <strong>รายละเอียด</strong>'
                    : 'กรุณาตรวจสอบข้อมูลในช่องที่ทำเครื่องหมายไว้',
                confirmButtonColor: '#DC2626', confirmButtonText: 'ไปตรวจสอบ'
            });
            return;
        }
        submitting = true;
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        }
        clearDraft();
        allowUnload = true;
        form.submit();
    }

    function doCancel(){
        var typeLabel = labelFromCard(form.querySelector('input[name="request_type"]:checked'));
        var hasData = getSelectedType() || (messageEl && messageEl.value.trim());
        if (!hasData) {
            clearDraft(); allowUnload = true; window.location.href = BACK_URL; return;
        }
        Swal.fire({
            title: 'ยืนยันการยกเลิก',
            html: 'ข้อมูลที่กรอกไว้ <strong>จะไม่ถูกบันทึก</strong>'
                + (typeLabel ? '<br><span style="font-size:0.85rem">ประเภท: <strong>' + typeLabel + '</strong></span>' : ''),
            icon: 'warning', showCancelButton: true,
            confirmButtonColor: '#DC2626', cancelButtonColor: '#6B7280',
            confirmButtonText: 'ยกเลิกและไม่บันทึก', cancelButtonText: 'กลับไปกรอกต่อ'
        }).then(function(r){
            if (r.isConfirmed) {
                clearDraft(); allowUnload = true; window.location.href = BACK_URL;
            }
        });
    }

    if (cancelBtn) cancelBtn.addEventListener('click', doCancel);
    form.addEventListener('submit', function(e){ e.preventDefault(); doSubmit(); });

    window.addEventListener('beforeunload', function(e){
        if (allowUnload || submitting) return;
        var dirty = getSelectedType() || (messageEl && messageEl.value.trim()) || (detailEl && detailEl.value.trim());
        if (!dirty) return;
        e.preventDefault();
        e.returnValue = '';
        return '';
    });

    document.addEventListener('keydown', function(e){
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            if (!submitting) doSubmit();
            return;
        }
        if (e.key === 'Escape') {
            if (window.Swal && Swal.isVisible()) return;
            e.preventDefault();
            doCancel();
        }
    });

    // Draft restore
    function offerDraftRestore(){
        var raw = null;
        try { raw = sessionStorage.getItem(DRAFT_KEY); } catch (e) { return; }
        if (!raw) return;
        var draft;
        try { draft = JSON.parse(raw); } catch (e) { return; }
        if (!draft || (!draft.request_type && !String(draft.message || '').trim())) return;
        if (!window.Swal) return;

        var when = '';
        if (draft.saved_at) {
            try { when = new Date(draft.saved_at).toLocaleString('th-TH', { dateStyle:'short', timeStyle:'short' }); }
            catch (e) {}
        }
        Swal.fire({
            title: 'พบข้อมูลที่ยังไม่ได้บันทึก',
            html: 'เมื่อ <strong>' + (when || 'ก่อนหน้านี้') + '</strong> คุณกรอกข้อมูลไว้ แต่ยังไม่ได้บันทึก<br>ต้องการกู้คืนหรือไม่?',
            icon: 'question', showCancelButton: true,
            confirmButtonColor: GC, cancelButtonColor: '#6B7280',
            confirmButtonText: 'กู้คืนข้อมูล', cancelButtonText: 'เริ่มใหม่'
        }).then(function(r){
            if (r.isConfirmed) { applyDraft(draft); refreshSummary(); }
            else clearDraft();
        });
    }

    // Step nav
    $$('.step-chip[data-jump]').forEach(function(chip){
        chip.addEventListener('click', function(){
            var t = document.getElementById(chip.getAttribute('data-jump'));
            if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    var sections = ['sec1','sec2','sec3','sec4'].map(function(id){ return document.getElementById(id); }).filter(Boolean);
    var chips = $$('.step-chip[data-jump]');
    if (sections.length && 'IntersectionObserver' in window) {
        var observer = new IntersectionObserver(function(entries){
            entries.forEach(function(entry){
                if (!entry.isIntersecting) return;
                chips.forEach(function(chip){
                    chip.classList.toggle('active', chip.getAttribute('data-jump') === entry.target.id);
                });
            });
        }, { rootMargin: '-20% 0px -60% 0px', threshold: 0 });
        sections.forEach(function(s){ observer.observe(s); });
    }

    form.addEventListener('input', function(){ refreshSummary(); saveDraft(); });
    form.addEventListener('change', function(){ refreshSummary(); saveDraft(); });

    syncStatusFromResult();
    refreshSummary();
    offerDraftRestore();
})();
</script>

<?php require_once __DIR__ . '/includes/timeout_guard.php'; ?>
</body>
</html>